#ifndef CPU_AND_NODE_H_
#define CPU_AND_NODE_H_

extern void get_cpu_and_node_(int& cpu, int& node);

#endif
