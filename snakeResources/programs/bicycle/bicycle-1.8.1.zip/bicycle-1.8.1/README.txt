bicycle version 1.8.1
----------------------------------
Use the "bicycle" script located at "cmd/bicycle" to run bicycle.

See the online manual for a detailed description of each command: http://www.sing-group.org/bicycle/manual.html
